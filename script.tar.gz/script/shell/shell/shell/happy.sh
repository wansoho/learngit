#!/bin/bash
date
# 农历四月十六

echo -e "dear caofeng,the day is your brithday!"




                      echo "happy"
                                     echo "brithday"
                                                       echo -e "\033[44;37;5m ME\033[0m COOL" 
                                                       echo   "to" "\nnn";
                                                                             echo  "you"
