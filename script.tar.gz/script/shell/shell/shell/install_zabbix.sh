#!/bin/bash
HNAME=`hostname`
#echo $HNAME
INSTALL_DIR="/neworiental/bj_zabbix_agentd"
groupadd --system zabbix
useradd --system -g zabbix  -s /sbin/nologin -c "Zabbix Monitoring System" zabbix

install_wget(){
   mkdir -p /neworiental;cd /neworiental
   wget http://10.15.4.169:81/zabbix-3.4.13.tar.gz
   wget http://10.15.4.169:81/zabbix_agentd.conf
   tar -zxf zabbix-3.4.13.tar.gz 
   cd zabbix-3.4.13/
   ./configure --prefix=${INSTALL_DIR}  --enable-agent && make && make install && chown  -R zabbix:zabbix ${INSTALL_DIR}
   rm -vf ${INSTALL_DIR}/etc/zabbix_agentd.conf;cp /neworiental/zabbix_agentd.conf ${INSTALL_DIR}/etc/
   sed -i 's/Hostname=Zabbix server/Hostname='${HNAME}'/' ${INSTALL_DIR}/etc/zabbix_agentd.conf
   chown zabbix:zabbix ${INSTALL_DIR}
   echo "/neworiental/bj_zabbix_agentd/sbin/zabbix_agentd">>/etc/rc.local
   ${INSTALL_DIR}/sbin/zabbix_agentd
   cd /neworiental;rm -vf zabbix-3.4.13.tar.gz zabbix_agentd.conf
}
install_wget;
