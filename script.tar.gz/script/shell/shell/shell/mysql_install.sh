#!/bin/bash

useradd www &>/dev/null;
while echo "请输入正确序号: "
do
select VER in "mysql" "php" "quit"
do
    case $VER in
        1)
         mysql_install;
             break
              ;;
        2)
     clear;
     echo -e "\033[31m-- RXSG2 VERSION --\033[0m";
     echo "1)--| [mysql-5.1.51]"
     echo "2)--| [mysql-5.5.45]"
     read -p "请选择:" NA
     case $NA in
    
      mysql-5.1.51)
         mysql_install
              ;;
      mysql-5.5.45)
         mysql_install
              ;;
      quit)
            exit
              ;;
       *)
           continue
              ;;
    esac


#esac
#exit

mysql_install (){

   mkdir -p /downloads;cd /downloads;wget http://210.14.138.81/LNMP/$VER.tar.gz
   tar -zxf $VER.tar.gz;cd $VER
   ./configure --user=www --group=www --prefix=/usr/local/mysql --localstatedir=/var/lib/mysql --with-comment=Source --with-server-suffix=-enterprise-
gpl --with-mysqld-user=mysql --without-debug --with-big-tables --with-charset=utf8 --with-collation=utf8_general_ci --with-extra-charsets=all --with-p
thread --enable-static --enable-thread-safe-client --with-client-ldflags=-all-static --with-mysqld-ldflags=-all-static --enable-assembler --without-nd
b-debug --without-isam
    make $$ make install
}
break
esac
continue
done
break
done
