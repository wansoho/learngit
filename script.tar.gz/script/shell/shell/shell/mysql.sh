#!/bin/bash
#MYSQL51=mysql-5.1.51
#MYSQL55=mysql-5.5.45
#while echo ""
useradd www &>/dev/null;
mysql_install (){
    mkdir -p /downloads;cd /downloads;wget http://210.14.138.81/LNMP/$VER.tar.gz
    tar -zxf $VER.tar.gz;cd $VER
   ./configure  --user=www --group=www --prefix=/usr/mysql --localstatedir=/var/mysql --with-comment=Source --with-server-suffix=-enterprise-gpl --with-mysqld-user=mysql --without-debug --with-big-tables --with-charset=utf8 --with-collation=utf8_general_ci --with-extra-charsets=all --with-pthread --enable-static --enable-thread-safe-client --with-client-ldflags=-all-static --with-mysqld-ldflags=-all-static --enable-assembler --without-nb-debug --without-isam
    make && make install || ret="1";
        if [ "X$ret" == "X1" ];then
                echo -e "\033[32m Install Fail...\033[0m\n" ;
        fi
        cd ../
        echo -e "\033[35m $VER Install Successful...\033[0m\n";
}

while echo "请输入正确序号: "
do
select VER in "mysql-5.1.51" "mysql-5.5.45" "quit"
do
    case $VER in
     mysql-5.1.51)
         mysql_install    
              ;;
     mysql-5.5.45)
         mysql_install
              ;;
     quit)
             exit
              ;;
      *)
            continue
              ;;
       esac
done
done
