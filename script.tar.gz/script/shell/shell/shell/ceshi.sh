#!/bin/bash
a=[ 1 2 3]
until [ $# -eq 0 ]
do
echo "第一个参数为: $1 参数个数为: $#"
shift
done
