#!/bin/bash
while echo "please command: "
do
select vi in "hostname" "ifconfig" "df -h" "quit"
do
case $vi in      
"hostname")
     hostname
      ;;
"ifconfig")
     ifconfig
      ;;
"df -h")
     df -h
      ;;
"quit")
     exit ;;
*)
    continue
      ;;
 esac
#break
done
break
done
