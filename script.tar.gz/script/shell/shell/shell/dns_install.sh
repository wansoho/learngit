##!/bin/bash
#yum install bind bind-chroot -y
#sed -i  ‘s/127\.0\.0\.1/any/’ /etc/named.conf
#sed -i  's/::1/any/' /etc/named.conf
#sed -i  's/localhost/any/' /etc/named.conf
#sed -i  's/^dnssec/\/\/&/' /etc/named.conf
#
#cat >> /etc/named.rfc1912.zones << ENDF
#zone "rsyslog1.com" IN {
#type master;
#file "rsyslog1.com.zone";
#allow-update { none; };
#};
#ENDF
#
#
#cp -p /var/named/named.localhost /var/named/rsyslog1.com.zone
#sed -i '/127.0.0.1\|AAAA/d' /var/named/rsyslog1.com.zone
#
#cat >> /var/named/rsyslog1.com.zone << ENDF
#      A       192.168.100.109
#www   A       192.168.100.109 
#ENDF 
#
#
#
#sed -i '1inameserver 192.168.100.109' /etc/resolv.conf
#/etc/rc.d/init.d/named restart
#nslookup www.rsyslog1.com

#1.dns配置脚本
#yum install bind bind-chroot -y
#cd /var/named/chroot/etc;touch named.conf
#cd /var/named/chroot/var/named;touch bogon.com.zone
#cat >> /var/named/chroot/etc/named.conf << EOF
#options
#{
#        directory               "/var/named";
#};
#zone   "bogon.com"
#{
#      type  master;
#      file "bogon.com.zone";
#};
#EOF
#cat >> /var/named/chroot/var/named/bogon.com.zone << EOF
#@       IN SOA  @  root (
#                                        0       ; serial
#                                       1D      ; refresh
#                                        1H      ; retry
#                                        1W      ; expire
#                                        3H )    ; minimum
#bogon.com.           IN NS   .
#master.bogon.com.    IN A    192.168.23.129
#www.bogon.com.       IN A    192.168.23.129
#EOF
#
#/etc/init.d/named start
#echo "" >/etc/resolv.conf
#dig master.bogon.com
########################主dns的配置脚本##############################
#定义变量
Packages="bind bind-chroot"
MYIP="$(ifconfig eth0 | grep "inet addr:" | cut -d":" -f2 | cut -d " " -f1)"
config_file="/var/named/chroot/etc/named.conf"
config_zone="/var/named/chroot/var/named/bogon.com.zone"

yum install $Packages -y
cp /usr/share/doc/bind-9.8.2/sample/etc/named.conf /var/named/chroot/etc
echo "">$config_file
cp /usr/share/doc/bind-9.8.2/sample/var/named/my.external.zone.db /var/named/chroot/var/named
mv /var/named/chroot/var/named/my.external.zone.db $config_zone
ehco "">$config_zone
cat >> $config_file << EOF
options
{
        directory               "/var/named";
};
zone   "bogon.com"
{
      type  master;
      file "bogon.com.zone";
};
EOF
cat >> $config_zone << EOF
@       IN SOA  @  root (
                                        0       ; serial
                                        1D      ; refresh
                                        1H      ; retry
                                        1W      ; expire
                                        3H )    ; minimum
bogon.com.           IN NS   .
master.bogon.com.    IN A   $MYIP 
www.bogon.com.       IN A   $MYIP 
EOF

/etc/init.d/named start
echo "" >/etc/resolv.conf
dig master.bogon.com
########################################dns脚本2#######################
#!/bin/bash
PKG="bind bind-chroot"
MYIP="$(ifconfig eth0 | grep "inet addr:" | cut -d":" -f2 | cut -d " " -f1)"
config_file="/var/named/chroot/etc/named.conf"
config_zone="/var/named/chroot/var/named/bogon.com.zone"

INSTALL_PKG() //安装包定义一个函数
{              
            yum install $PKG -y
            for i in $PKG
            do
            rpm -q $i &>/dev/null               # -q列出所有未被安装的包
            [ $? -ne 0 ] && UNPKG="$UNPKG $i"  //将所有检测出来未安装的包保存到变量UPPKG中，也可以保存到文件中，不过变量是临时存储在内存中的，速度要比文件快的多，其次可以减少磁盘I/O性能。
            done
            [ -n "$UNPKG"] && yum install $UNPKG -y //判断变量UNPKG是否为空，如果不为空就安装里面包含的包
 }


MAIN_CONF()   //配置文件和zone文件定义一个函数
{          
            cp /usr/share/doc/bind-9.8.2/sample/etc/named.conf /var/named/chroot/etc
            echo "">$config_file
            cp /usr/share/doc/bind-9.8.2/sample/var/named/my.external.zone.db /var/named/chroot/var/named
            mv /var/named/chroot/var/named/my.external.zone.db $config_zone
            ehco "">$config_zone
            cat >> $config_file << EOF
options
{
        directory               "/var/named";
};
zone   "bogon.com"
{
      type  master;
      file "bogon.com.zone";
            ehco "">$config_zone
};
EOF
cat >> $config_zone << EOF
@       IN SOA  @  root (
                                        0       ; serial
                                        1D      ; refresh
                                        1H      ; retry
                                        1W      ; expire
                                        3H )    ; minimum
bogon.com.           IN NS   .
master.bogon.com.    IN A   $MYIP 
www.bogon.com.       IN A   $MYIP 
EOF
}


MYTEST()  //dns测试定义一个函数
{  
            echo "" >/etc/resolv.conf
            /etc/init.d/named start
            dig www.master.bogon.com
}

INSTALL_PKG 
MAIN_CONF 
MYTEST
######################################安装完毕#############################
