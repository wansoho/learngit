#!/bin/bash
cd /opt/script/shell
while echo "please input ip: "
do
read ip
 if  [[ $ip =~ ^[0-9]{1,3}/.[0-9]{1,3}/.[0-9]{1,3}/.[0-9]{1,3}$ ]]; then
         OIFS=$IFS
         IFS='.'
         ip=($ip)
         IFS=$OIFS
         [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
         stat=$?  
  # echo "its ok" 
#  else echo "please input ture ip"

while echo "please choose game: "
do
select game in "rxsg" "rxsg2" "rxsg3" "zlsg" "quit"
do
case $game in
  rxsg)
      echo "allow $ip;" >> 1.txt
          ;;
  rxsg2)
      echo "allow $ip;" >> 1.txt
          ;;
  rxsg3)
      echo "allow $ip;" >> 1.txt
          ;;
  zlsg)
      echo "allow $IP;" >> 1.txt
          ;;
  quit)
       exit;;
*)
      continue
          ;;
 esac
break

done
break
done
else echo "please  input ture ip "
fi
done

#exit
