#!/bin/bash
cd /opt
   for i in `cat quitip.lst`
    do
    cat ipall.lst |grep "$i"
    if [ $? -eq 0 ]
    then
     sed -i "/$i/d" /opt/ipall.lst
  fi
done
