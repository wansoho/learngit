#!/bin/bash

echo "please input the num (1-20): "
read num
while [[ $num != 4 ]]
do
if [ $num -lt 4 ]
then
  echo "too small,try again.."
read num
 elif [ $num -gt 4 ]
then
  echo "Too big ,Try again.. "
read num
 else
 exit 0
fi
done
  echo "Yes ,you are right !!"
