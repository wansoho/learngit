#!/bin/bash

while echo "please input \"yes\" or \"no\" or \"y\" \"n\" "
do
read ar

case "$ar" in
[yY][eE][sS])
      echo "your input is YES"
            ;;
[nN][oO])
      echo "your input is NO" 
            ;;
[yY])
      echo "your input is Y" 
            ;;
[nN])
      echo "your input is N" 
            ;;
*)
       continue      
           ;;

esac
break
done
exit 0
