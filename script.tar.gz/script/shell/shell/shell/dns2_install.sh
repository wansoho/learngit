#!/bin/bash
PKG="bind bind-chroot"
MYIP="$(ifconfig eth0 | grep "inet addr:" | cut -d":" -f2 | cut -d " " -f1)"
config_file="/var/named/chroot/etc/named.conf"
config_zone="/var/named/chroot/var/named/bogon.com.zone"

INSTALL_PKG()   #安装包定义一个函数
{
            yum install $PKG -y
            for i in $PKG
            do
            rpm -q $i &>/dev/null               # -q列出所有未被安装的包
            [ $? -ne 0 ] && UNPKG="$UNPKG $i"  #将所有检测出来未安装的包保存到变量UPPKG中，也可以保存到文件中，不过变量是临时存储在内存中的，速度要比文件快的多，其次可以减少磁盘I/O性能。
            done
            [ -n "$UNPKG"] && yum install $UNPKG -y #判断变量UNPKG是否为空，如果不为空就安装里面包含的包
 }


MAIN_CONF()   #配置文件和zone文件定义一个函数
{
            cp /usr/share/doc/bind-9.8.2/sample/etc/named.conf /var/named/chroot/etc
            echo "">$config_file
            cp /usr/share/doc/bind-9.8.2/sample/var/named/my.external.zone.db /var/named/chroot/var/named
            mv /var/named/chroot/var/named/my.external.zone.db $config_zone
            ehco "">$config_zone
            cat >> $config_file << ENDF
options
{
        directory               "/var/named";
};
zone   "bogon.com"
{
      type  master;
      file "bogon.com.zone";
            ehco "">$config_zone
};
ENDF
cat >> $config_zone << ENDF
@       IN SOA  @  root (
                                        0       ; serial
                                        1D      ; refresh
                                        1H      ; retry
                                        1W      ; expire
                                        3H )    ; minimum
bogon.com.           IN NS   .
master.bogon.com.    IN A   $MYIP 
www.bogon.com.       IN A   $MYIP 
ENDF
}


MYTEST()  #dns测试定义一个函数
{
            echo "" >/etc/resolv.conf
            /etc/init.d/named start
            dig www.master.bogon.com
}

INSTALL_PKG
MAIN_CONF
MYTEST
