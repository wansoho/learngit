#!/bin/bash
#随机抽奖脚本 date:20160114
