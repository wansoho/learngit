#!/bin/bash
   for i in `cat 1.txt`
   do
   ssh 
