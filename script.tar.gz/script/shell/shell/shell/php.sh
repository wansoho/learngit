#!/bin/bash
web=210.14.138.81
path=/usr/local/php-5.4.15/bin/php-config

#define下载安装包函数
mkdir -p /downloads;cd /downloads;
update_package()
{     
      wget http://$web/LNMP/php-5.4.15.tar.bz2
      wget http://$web/LNMP/mongo-1.6.12.tgz
      wget http://$web/LNMP/php-fpm-5.4.15.conf
      wget http://$web/LNMP/php-5.4.15.ini
      wget http://$web/LNMP/yaf-2.2.9.tgz
      wget http://$web/LNMP/memcache-2.2.6.tgz
      wget http://$web/LNMP/zendopcache-7.0.5.tgz
      wget http://$web/LNMP/PDO_MYSQL-1.0.2-php-5.4.15.tar.gz

     if [ -f PDO_MYSQL-1.0.2-php-5.4.15.tar.gz ];           then echo "download ok"; else echo "download faild PDO_MYSQL-1.0.2-php-5.4.15.tar.gz";fi
     if [ -f php-fpm-5.4.15.conf ];                         then echo "download ok"; else echo "download faild php-fpm-5.4.15.conf";fi
     if [ -f php-5.4.15.ini ];                              then echo "download ok"; else echo "download faild php-5.4.15.ini";fi
     if [ -f mongo-1.6.12.tgz ];                            then echo "download ok"; else echo "download faild mongo-1.6.12.tgz";fi 
     if [ -f yaf-2.2.9.tgz ];                               then echo "download ok"; else echo "download faild yaf-2.2.9.tgz";fi
     if [ -f memcache-2.2.6.tgz ];                          then echo "download ok"; else echo "download faild memcache-2.2.6.tgz";fi
     if [ -f zendopcache-7.0.5.tgz ];                       then echo "download ok"; else echo "download faild zendopcache-7.0.5.tgz";fi
}

unzip_package()
{
      cd /downloads;
      tar -xjf php-5.4.15.tar.bz2;
      tar -zxf  mongo-1.6.12.tgz;
      tar -zxf  yaf-2.2.9.tgz;
      tar -zxf  memcache-2.2.6.tgz;
      tar -zxf zendopcache-7.0.5.tgz;
}

install_php()
{
      cd /downloads/php-5.4.15/;
      if [ $? > 0 ];then
      ./configure \
--prefix=/usr/local/php-5.4.15 \
--with-config-file-path=/usr/local/php-5.4.15/etc \
--with-mysql=/usr/local/mysql \
--with-mysqli=/usr/local/mysql/bin/mysql_config \
--with-iconv=/usr/local \
--with-freetype-dir \
--with-jpeg-dir \
--with-png-dir \
--with-zlib \
--with-libxml-dir=/usr \
--enable-xml \
--enable-discard-path \
--enable-safe-mode \
--enable-bcmath \
--enable-shmop \
--enable-sysvsem \
--enable-inline-optimization \
--with-curl \
--with-curlwrappers \
--enable-mbregex \
--enable-fastcgi \
--enable-fpm \
--enable-force-cgi-redirect \
--enable-mbstring \
--with-mcrypt \
--with-gd \
--enable-gd-native-ttf \
--with-mhash \
--enable-pcntl \
--enable-sockets \
--with-xmlrpc \
--with-openssl \
--enable-soap \
--enable-zip

make && make install
      else
      exit;
     
 fi

#检查/usr/local/php/sbi/php-fpm文件是否生成
if [ ! -f /usr/local/php-5.4.15/sbin/php-fpm ];then
  echo "PHP make install is Failed!"
  exit;
fi
}
#扩展安装
install_extend()
{
#####mongo安装#####
cd /downloads/mongo-1.6.12;
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=$path
make && make install
####memcache安装####
cd /downloads/memcache-2.2.6;
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=$path
make && make install
###yaf安装#######
cd /downloads/yaf-2.2.9;
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=$path
make && make install
######zendopcache安装#############
cd /downloads/zendopcache-7.0.5;
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=$path
make && make install
##pdo_mysql扩展
cd /downloads/PDO_MYSQL-1.0.2;
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=$patch --with-pdo-mysql=/usr/local/mysql
make && make install

###拷贝配置文件
rm -f /usr/local/php-5.4.15/etc/php.ini
rm -f /usr/local/php-5.4.15/etc/php-fpm.conf
cd /downloads;
/bin/cp -f php-5.4.15.ini /usr/local/php-5.4.15/etc/php.ini
cp php-fpm-5.4.15.conf /usr/local/php-5.4.15/etc/php-fpm.conf
mkdir -p /data/web/yaf
cd /data/web/yaf;
mv /downloads/yaf.tar.gz ./;
tar -zxf yaf.tar.gz;
/bin/rm -f yaf.tar.gz;
####在/etc/rc.local末尾增加以下内容
echo "/usr/local/php-5.4.15/sbin/php-fpm" >> /etc/rc.local
###制作启动方式#####
cp /downloads/php-5.4.15/sapi/fpm/init.d.php-fpm /etc/init.d/php54-fpm.sh
chmod +x /etc/init.d/php54-fpm.sh
}

main(){
    
      update_package;
      unzip_package;
      install_php;
      install_extend;

}
main;
