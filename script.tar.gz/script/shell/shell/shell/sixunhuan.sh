#!/bin/bash

cat /opt/script/shell/1.txt|while read line

#while (( $line -eq 0 ))

for(i=1;i<=10;i++)

do

echo "das"

done
