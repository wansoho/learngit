#!/bin/bash

useradd www &>/dev/null;a
function check_ok(){
  if [ $? -eq 0 ]
  then
    continue
  else
    echo "please check error"
    exit
  fi
}
yum install gcc gcc-c++ make ncurses-devel libtool ntp -y
mysql51_install (){
        mkdir -p /downloads;cd /downloads;wget http://210.14.138.81/LNMP/$VER.tar.gz
        tar -zxf $VER.tar.gz;cd $VER
   ./configure --prefix=/usr/mysql --localstatedir=/var/mysql --with-comment=Source --with-server-suffix=-enterprise-gpl --with-mysqld-user=mysql --without-debug --with-big-tables --with-charset=utf8 --with-collation=utf8_general_ci --with-extra-charsets=all --with-pthread --enable-static --enable-thread-safe-client --with-client-ldflags=-all-static --with-mysqld-ldflags=-all-static --enable-assembler --without-nb-debug --without-isam
        make && make install || ret="1";
        if [ "X$ret" == "X1" ];then
                echo -e "\033[32m Install Fail...\033[0m\n" ;
        fi
        cd ../
        echo -e "\033[35m mysql Install Successful...\033[0m\n";
}

mysql55_install (){
        mkdir -p /downloads;cd /downloads;wget http://210.14.138.81/LNMP/$VER.tar.gz
        tar -zxf $VER.tar.gz;cd $VER
#        if [ -n `which cmake` ];then
#           echo "cmake installed"
#         else
#        yum install cmake -y
         cd /downloads;
         wget http://210.14.138.81/LNMP/cmake-2.8.4.tar.gz
         tar -zxf  cmake-2.8.4.tar.gz;cd  cmake-2.8.4
         ./configure --prefix=/usr/local/cmake
        #  check_ok
          gmake && gmake install
        # check_ok               
        #   yum install gmake -y
#      fi
          cd /downloads/$VER;
          cmake . -DCMAKE_INSTALL_PREFIX=/opt/mysql/ -DSYSCONFDIR=/opt/mysql/etc -DMYSQL_DATADIR=/var/mysql -DEXTRA_CHARSETS=all -DDEFAULT_CHARSET=utf8 -DDEFAULT_COLLATION=utf8_general_ci
         make && make install
        if [ "X$ret" == "X1" ];then
                echo -e "\033[32m Install Fail...\033[0m\n" ;
        fi
        cd ../
        echo -e "\033[35m mysql Install Successful...\033[0m\n";
}

while echo "请输入正确序号: "
do
select VER in "mysql-5.1.51" "mysql-5.5.45" "quit"
do
    case $VER in
      mysql-5.1.51)
           mysql51_install
              ;;
      mysql-5.5.45)
           mysql55_install
              ;;
      quit)
            exit
              ;;
       *)
           continue
              ;;
    esac
 done
done
