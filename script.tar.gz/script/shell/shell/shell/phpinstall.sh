#!/bin/bash

useradd www &>/dev/null;
function check_ok(){
  if [ $? -eq 0 ]
  then
    continue
  else
    echo "please check error"
    exit
  fi
}
#安装依赖库
library_install (){
        yum -y install gcc gcc-c++ autoconf libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel libxml2 libxml2-devel zlib zlib-devel glibc glibc-devel glib2 glib2-devel bzip2 bzip2-devel ncurses ncurses-devel curl curl-devel e2fsprogs e2fsprogs-devel krb5 krb5-devel libidn libidn-devlopenssl openssl-devel openldap openldap-devel nss_ldap openldap-clients openldap-servers ImageMagick-devel net-snmp-devel gd xinetd pcre-devel patch  ncurses-static zlib-static
}
#php支持库
phplibrary_install(){
cd /downloads;
tar zxvf libiconv-1.13.1.tar.gz
cd libiconv-1.13.1/
./configure --prefix=/usr/local
make && make install && cd ../

tar zxvf libmcrypt-2.5.8.tar.gz
cd libmcrypt-2.5.8/
./configure && make && make install
/sbin/ldconfig
cd libltdl/
./configure --enable-ltdl-install
make && make install
cd ../../

tar zxvf mhash-0.9.9.9.tar.gz
cd mhash-0.9.9.9/
./configure
make && make install
cd ../

ln -s /usr/local/lib/libmcrypt.la /usr/lib/libmcrypt.la
ln -s /usr/local/lib/libmcrypt.so /usr/lib/libmcrypt.so
ln -s /usr/local/lib/libmcrypt.so.4 /usr/lib/libmcrypt.so.4
ln -s /usr/local/lib/libmcrypt.so.4.4.8 /usr/lib/libmcrypt.so.4.4.8
ln -s /usr/local/lib/libmhash.a /usr/lib/libmhash.a
ln -s /usr/local/lib/libmhash.la /usr/lib/libmhash.la
ln -s /usr/local/lib/libmhash.so /usr/lib/libmhash.so
ln -s /usr/local/lib/libmhash.so.2 /usr/lib/libmhash.so.2
ln -s /usr/local/lib/libmhash.so.2.0.1 /usr/lib/libmhash.so.2.0.1
ln -s /usr/local/lib/libmcrypt.la /usr/lib64/libmcrypt.la
ln -s /usr/local/lib/libmcrypt.so /usr/lib64/libmcrypt.so
ln -s /usr/local/lib/libmcrypt.so.4 /usr/lib64/libmcrypt.so.4
ln -s /usr/local/lib/libmcrypt.so.4.4.8 /usr/lib64/libmcrypt.so.4.4.8
ln -s /usr/local/lib/libmhash.a /usr/lib64/libmhash.a
ln -s /usr/local/lib/libmhash.la /usr/lib64/libmhash.la
ln -s /usr/local/lib/libmhash.so /usr/lib64/libmhash.so
ln -s /usr/local/lib/libmhash.so.2 /usr/lib64/libmhash.so.2
ln -s /usr/local/lib/libmhash.so.2.0.1 /usr/lib64/libmhash.so.2.0.1
ln -s /usr/local/bin/libmcrypt-config /usr/bin/libmcrypt-config
ln -s /usr/lib64/libjpeg.so /usr/lib/
ln -s /usr/lib64/libpng.so /usr/lib/

tar zxvf mcrypt-2.6.8.tar.gz
cd mcrypt-2.6.8/
/sbin/ldconfig
./configure
make && make install && cd ../
}


#安装扩展
extend_install(){
#####mongo安装#####
cd /downloads
wget 210.14.138.81/LNMP/mongo-1.6.12.tgz
tar -zxf mongo-1.6.12.tgz
cd mongo-1.6.12;/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=/usr/local/php-5.4.15/bin/php-config
make && make install
####memcache安装####
cd /downloads
wget 210.14.138.81/LNMP/memcache-2.2.6.tgz
tar -zxf memcache-2.2.6.tgz
cd memcache-2.2.6;/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=/usr/local/php-5.4.15/bin/php-config
make && make install
###yaf安装#######
cd /downloads
wget 210.14.138.81/LNMP/yaf-2.2.9.tgz
tar -zxf yaf-2.2.9.tgz
cd yaf-2.2.9;/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=/usr/local/php-5.4.15/bin/php-config
make && make install
######zendopcache安装#############
wget 210.14.138.81/LNMP/zendopcache-7.0.5.tgz
tar -zxf zendopcache-7.0.5.tgz ;cd zendopcache-7.0.5
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=/usr/local/php-5.4.15/bin/php-config
make && make install
##pdo_mysql扩展
wget http://210.14.138.81/LNMP/PDO_MYSQL-1.0.2-php-5.4.15.tar.gz
cd /downloads/
tar -zxf PDO_MYSQL-1.0.2-php-5.4.15.tar.gz
cd PDO_MYSQL-1.0.2
/usr/local/php-5.4.15/bin/phpize
./configure --with-php-config=/usr/local/php-5.4.15/bin/php-config --with-pdo-mysql=/usr/local/mysql
make && make install       
}
php52_install (){
###编译安装php(fastcgi模式)
wget http://210.14.138.81/LNMP/$VER.tar.gz
wget http://210.14.138.81/LNMP/$VER--fpm-0.5.14.diff.gz
cd /downloads
tar zxvf php-5.2.17.tar.gz
gzip -cd php-5.2.17-fpm-0.5.14.diff.gz | patch -d php-5.2.17 -p1
cd php-5.2.17/
./configure \
--prefix=/usr/local/php-cgi \
--with-config-file-path=/usr/local/php-cgi/etc \
--with-mysql=/usr/local/mysql \
--with-mysqli=/usr/local/mysql/bin/mysql_config \
--with-iconv=/usr/local \
--with-freetype-dir \
--with-jpeg-dir \
--with-png-dir \
--with-zlib \
--with-libxml-dir=/usr \
--enable-xml \
--disable-rpath \
--enable-discard-path \
--enable-safe-mode \
--enable-bcmath \
--enable-shmop \
--enable-sysvsem \
--enable-inline-optimization \
--with-curl \
--with-curlwrappers \
--enable-mbregex \
--enable-fastcgi \
--enable-fpm \
--enable-force-cgi-redirect \
--enable-mbstring \
--with-mcrypt \
--with-gd \
--enable-gd-native-ttf \
--with-openssl \
--with-mhash \
--enable-pcntl \
--enable-sockets \
--with-ldap \
--with-ldap-sasl \
--with-xmlrpc \
--enable-zip \
--enable-soap
make && make install
#check_ok
}
php54_install (){

     mkdir -p /downloads;cd /downloads
     wget http://210.14.138.81/LNMP/$ver.tar.gz
     tar -zxf $ver.tar.gz;cd $ver
     ./configure \
--prefix=/usr/local/php-5.4.15 \
--with-config-file-path=/usr/local/php-5.4.15/etc \
--with-mysql=/usr/local/mysql \
--with-mysqli=/usr/local/mysql/bin/mysql_config \
--with-iconv=/usr/local \
--with-freetype-dir \
--with-jpeg-dir \
--with-png-dir \
--with-zlib \
--with-libxml-dir=/usr \
--enable-xml \
--enable-discard-path \
--enable-safe-mode \
--enable-bcmath \
--enable-shmop \
--enable-sysvsem \
--enable-inline-optimization \
--with-curl \
--with-curlwrappers \
--enable-mbregex \
--enable-fastcgi \
--enable-fpm \
--enable-force-cgi-redirect \
--enable-mbstring \
--with-mcrypt \
--with-gd \
--enable-gd-native-ttf \
--with-mhash \
--enable-pcntl \
--enable-sockets \
--with-xmlrpc \
--with-openssl \
--enable-soap \
--enable-zip
#     check_ok
     make && make install
     check_ok
}

while echo "请输入正确序号: "
do
select VER in "php-5.2.17" "php-5.4.15" "quit"
do
    case $VER in
      php-5.2.17)
          library_install
          phplibrary_install
          extend_install 
           php52_install
              ;;
      php-5.4.15)
           library_install
           phplibrary_install
           extend_install
           php54_install
              ;;
      quit)
            exit
              ;;
       *)
           continue
              ;;
    esac
 done
done
