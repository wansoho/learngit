#/usr/bin/python
#coding=utf-8

while True:
    num = raw_input('please input a number:')
    try:
      num = int(num)
      break

