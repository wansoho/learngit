#!/usr/bin/python2.7

t= 'abc'
r= ''
#加密
for i in t:
    r += chr(ord(i) << 1)
    #上行相当于 r = r + chr(ord(i) <<1) 
print r

#ord 是将字符转成数字  

#解密
for i in r:
print chr(ord(i) >> 1)
print r

