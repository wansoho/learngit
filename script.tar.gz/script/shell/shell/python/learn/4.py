#/usr/bin/python
#coding:utf-8
import os
depts = ['综合部','销售部']
for dept in depts:
    try:
       os.mkdir(dept)
    except OSError as e:
        print '文件[%s]创建失败，原因是:[%s]' % (dept,e.strerror)
#        打印错误异常    %s 文件格式   

##语法 异常处理 try:
#   ..
#   ..
#  except OSError(异常类型)  as e: 
