#/usr/bin/python2.7
#encoding:utf-8
import os

depts = ['产品部','人事部','技术部']
print depts[2]
for dept in depts:
    print dept
    result = os.popen("mkdir %s" % dept)
    print result
    is_success = False
    if not result.read():
       is_success = Ture
#    if dept in result.read():
#        print 'success'
#    else:
#        print 'fail',dept
