#/usr/bin/python2.7
#coding:utf-8


import os


depts = ['人事部','财务部','运营部']

for dept in depts:
 
     os.mkdir(dept)
