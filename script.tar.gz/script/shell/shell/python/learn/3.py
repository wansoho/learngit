#/usr/bin/python2.7
#encoding:utf-8
import os

depts = ['人事部', '事业部']
print depts[1]
