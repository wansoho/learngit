#!/usr/bin/python2.7
# coding:utf-8
# author: the5fire
import urllib2
import bs4
url = 'http://http://user.qzone.qq.com/760837509?ptlang=2052'
content = urllib2.urlopen(url).read()

content = content.decode('utf-8')
print content
soup = bs4.BeautifulSoup(content)
#links = soup.select('li a[href]')
#links = soup.select('name')
#result = []
#for link in links:
#    title = link.attrs['name']
#    if 'per' in name and 'tid' in name >4:
#    biaoti = link.text
#    if '.html' in href and 'taobao.com' in href and len(title) > 3:
#        result.append(link)
#for link in result:
#    print link.attrs['name']
#    
#print '共有新闻[%s]条'% len(result)
