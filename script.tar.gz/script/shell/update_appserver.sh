#!/bin/bash

export BUILD_ID=dontkillme
ITEM_DIR=/home/work/tomcat-appserver
BACKUP_DIR=/data/backup
BACKUP_DATE=`date -d"yesterday $Date" +%Y%m%d`
FILE_DIR=/data/zipfile
pid_num=`ps aux|grep tomcat-appserver|grep -v grep|wc -l`

stop_server(){
  sh ${ITEM_DIR}/bin/shutdown.sh
  sleep 3
  pid=`ps aux|grep tomcat-appserver|grep -v 'grep'|awk '{print $2}'`
  if [ ${pid_num} != 0 ];then
     kill -9 $pid
  fi
}
backup_item(){
   cd ${BACKUP_DIR}
   tar -zcf appserver${BACKUP_DATE}.tar.gz $ITEM_DIR/webapps/appserver
}

update_tomcat(){
     svn co  svn://10.176.241.221/   $ITEM_DIR/webapps/
    # unzip -o ${FILE_DIR}/appserver.zip -d ${ITEM_DIR}/webapps/appserver
    # sleep 3
     cd ${ITEM_DIR}/bin;./startup.sh
     if [ ${pid_num} = 0 ];then
        sh ${ITEM_DIR}/bin/startup.sh
     else
        echo "tomcat-appserver start success!"
     fi
}
rollback(){
     cd BACKUP_DIR;
     new_backup=`ls appserver*.tar.gz|head -1`
     tar -zxf $new_backup -C $ITEM_DIR/webapps/
}

NUM=$1
if [ $NUM == 1 ];then
   stop_server
   backup_item
   update_tomcat
fi
if [ $NUM == 0 ];then
   stop_server
   backup_item
   rm -rf $ITEM_DIR/webapps/appserver
   update_tomcat
   
fi  
if [ $NUM == 2 ];then
   stop_server
   rollback
   start_server
fi  

