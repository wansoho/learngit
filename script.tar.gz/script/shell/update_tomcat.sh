#!/bin/bash
#更新tomcat项目的zip包
DTIME=`date +%Y%m%d`
DEST_IP="$workip"
W_NAME="$workname"
BIN_DIR="/neworiental/software/tomcat-{$W_NAME}/bin"
ZIP_DIR="/neworiental/software/tomcat-{$W_NAME}/webapps/"

########
function if_error
########
{
erron=$?
if [ $erron -ne 0 ]; then # check return code passed to function
   echo "error $1, code $erron" >&2
   exit $erron
fi
}
scp_file(){
   scp ${W_NAME}.zip ${DEST_IP}:/${ZIP_DIR}||$if_error
   }
backup_file(){
   ssh ${DEST_IP} "cd ${ZIP_DIR};cp -r $(W_NAME) $(W_NAME)_${DTIME}"||$if_error
   }
unzip_file(){
   ssh ${DEST_IP} "cd ${ZIP_DIR};unzip -o $(W_NAME).zip"||$if_error
   }
restart_tomcat(){
   ssh ${DEST_IP} "cd ${BIN_DIR};./shuntdown.sh & ./start.sh"||$if_error
   }
main(){
   scp_file;
   backup_file;
   unzip_file;
  restart_tomcat
}
main;
 ##############
 #1.拷贝包到远程服务器的相对目录下
 #2.备份原来的文件
 #3.解压文件
 #4.重启服务
