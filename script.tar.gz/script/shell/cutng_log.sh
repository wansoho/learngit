#!/bin/bash

Log_dir=/var/log/nginx
Date=`date +%Y%m%d`
log_date=`date -d"yesterday $Date" +%Y-%m-%d`
log_name=(access error)
cd $Log_dir;
for lg in ${log_name[@]}
   do
   cp $lg.log ${lg}_${log_date}.log
   if [ $? != 0 ];then
      echo "copy log error" >>$Log_dir/cpoy.file
   else
      >$lg.log
   fi
done
find $Log_dir/* -type f -name "*-*.log" -ctime 14 -exec rm -f {} \;
