#!/bin/sh
# 自动监控tomcat并且在异常时执行重启操作
# 定义java环境变量
export JAVA_HOME=/usr/local/myApp/jdk1.8
# 获取端口号为8080的tomcat进程ID(考虑到有多个tomcat服务器,用8080关键词)
pid=$(ps -ef |grep 8080|grep -v grep|awk '{print $2}')
start=/neworiental/tomcat8080/bin/startup.sh
# tomcat缓存
cache=/usr/local/myApp/tomcat8080/work
# tomcat链接地址
url=http://localhost:8080
# 监控时的日志输出
log=/tmp/my.log
#linux垃圾回收站
hole=/dev/null
function doIt(){
   if [ $pid ];then
      echo "tomcat进程ID存在"
      code=$(curl -s -o $hole -m 10 --connect-timeout 10 $url -w %{http_code}"\n") #测试链接是否可以正常访问
      if [ $code -eq 200 ];then
         echo "测试链接正常"
      else
         echo "测试链接失败，重启tomcat"
         kill -9 $pid # 杀掉进程
         sleep 5
         rm -rf $cache # 清理tomcat缓存
         $start
      fi
   else
      echo "tomcat进程id不存在，重启中...."
      rm -rf $cache
      $start
   fi
   echo "------------------------------"
}
doIt>>$log #执行函数，并打印日志
